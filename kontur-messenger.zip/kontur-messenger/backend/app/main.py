from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.api.router_page import router as page_router
from app.api.router_socket import router as socket_router

ROOT = Path(__file__).resolve().parents[2]
app = FastAPI(title="Контур · тестовый сервер")
app.include_router(socket_router)
app.include_router(page_router)
app.mount('/static', StaticFiles(directory=Path(__file__).parent / 'static'), name='static')

@app.get('/api/health')
async def health():
    return {'status': 'ok', 'mode': 'test', 'authentication': False, 'e2ee': False}

if (ROOT / 'dist').is_dir():
    app.mount('/', StaticFiles(directory=ROOT / 'dist', html=True), name='frontend')
