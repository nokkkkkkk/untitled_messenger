const data = document.getElementById('room-data');
const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
const ws = new WebSocket(`${protocol}//${location.host}/ws/chat/${data.dataset.roomId}/${data.dataset.userId}?username=${encodeURIComponent(data.dataset.username)}`);
const input = document.getElementById('messageInput');
function sendMessage() { if (input.value.trim() && ws.readyState === WebSocket.OPEN) { ws.send(input.value); input.value = ''; } }
ws.onmessage = event => {const item = JSON.parse(event.data); const el = document.createElement('div'); el.textContent = `${item.sender || ''}: ${item.text}`; el.style.cssText = `padding:12px;margin:8px;border-radius:8px;background:${item.is_self?'#dcefe3':'#eee'}`; document.getElementById('messages').append(el); el.scrollIntoView();};
input.addEventListener('keydown', event => { if(event.key === 'Enter') sendMessage(); });
