from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter, Request, Form
from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory=Path(__file__).resolve().parents[1] / 'templates')

@router.get('/legacy')
async def home_page(request: Request):
    return templates.TemplateResponse(request=request, name='home.html')

@router.post('/join_chat')
async def join_chat(request: Request, username: str = Form(min_length=1, max_length=32), room_id: int = Form(ge=1, le=999999999)):
    return templates.TemplateResponse(request=request, name='index.html', context={
        'username': username.strip(), 'room_id': room_id, 'user_id': str(uuid4())})
