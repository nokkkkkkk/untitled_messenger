from collections import deque
from datetime import datetime, timezone
from uuid import uuid4
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query

class ConnectionManager:
    def __init__(self):
        self.rooms = {}
        self.history = {}

    async def broadcast(self, room_id, payload, sender_id=None):
        failed = []
        for uid, connection in list(self.rooms.get(room_id, {}).items()):
            try:
                await connection.send_json({**payload, 'is_self': uid == sender_id})
            except (RuntimeError, WebSocketDisconnect):
                failed.append(uid)
        for uid in failed:
            self.disconnect(room_id, uid)

    def disconnect(self, room_id, user_id):
        connections = self.rooms.get(room_id, {})
        connections.pop(user_id, None)
        if not connections:
            self.rooms.pop(room_id, None)

manager = ConnectionManager()
router = APIRouter(prefix='/ws/chat')

@router.websocket('/{room_id}/{user_id}')
async def websocket_endpoint(websocket: WebSocket, room_id: int, user_id: str, username: str = Query(min_length=1, max_length=32)):
    if not 1 <= room_id <= 999999999 or not username.strip():
        await websocket.close(code=1008)
        return
    await websocket.accept()
    if user_id in manager.rooms.get(room_id, {}):
        await websocket.close(code=1008)
        return
    if room_id not in manager.history:
        if len(manager.history) >= 100:
            inactive = next((key for key in manager.history if key not in manager.rooms), None)
            if inactive is None:
                await websocket.send_json({'type': 'error', 'text': 'Сервер занят: слишком много комнат.'})
                await websocket.close(code=1013)
                return
            del manager.history[inactive]
        manager.history[room_id] = deque(maxlen=200)
    try:
        for item in manager.history[room_id]:
            await websocket.send_json({**item, 'is_self': item['sender_id'] == user_id})
        manager.rooms.setdefault(room_id, {})[user_id] = websocket
        while True:
            text = (await websocket.receive_text()).strip()
            if not text or len(text) > 4000:
                await websocket.send_json({'type': 'error', 'text': 'Сообщение должно содержать от 1 до 4000 символов.'})
                continue
            item = {'id': str(uuid4()), 'type': 'message', 'text': text, 'sender': username.strip(),
                    'sender_id': user_id, 'created_at': datetime.now(timezone.utc).isoformat()}
            manager.history[room_id].append(item)
            await manager.broadcast(room_id, item, user_id)
    except WebSocketDisconnect:
        pass
    finally:
        manager.disconnect(room_id, user_id)
