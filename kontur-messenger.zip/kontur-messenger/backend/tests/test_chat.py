from fastapi.testclient import TestClient
from app.main import app
from app.api.router_socket import manager

client = TestClient(app)

def test_health_and_pages():
    assert client.get('/api/health').json()['status'] == 'ok'
    assert client.get('/legacy').status_code == 200
    assert client.post('/join_chat', data={'username': 'Тест', 'room_id': 1}).status_code == 200
    assert client.post('/join_chat', data={'username': 'Тест', 'room_id': -1}).status_code == 422

def test_two_clients_history_validation_and_isolation():
    manager.rooms.clear()
    manager.history.clear()
    with client.websocket_connect('/ws/chat/1/one?username=One') as one:
        with client.websocket_connect('/ws/chat/1/two?username=Two') as two:
            one.send_text('Привет <script>')
            a, b = one.receive_json(), two.receive_json()
            assert a['is_self'] and not b['is_self']
            assert a['text'] == b['text'] == 'Привет <script>'
            two.send_text('x' * 4001)
            assert two.receive_json()['type'] == 'error'
            with client.websocket_connect('/ws/chat/2/three?username=Three') as three:
                three.send_text('Другая комната')
                assert three.receive_json()['text'] == 'Другая комната'
        with client.websocket_connect('/ws/chat/1/four?username=Four') as four:
            assert four.receive_json()['text'] == 'Привет <script>'
    assert not manager.rooms
