import React from 'react';
import { CheckCheck } from 'lucide-react';
export default function MessageBubble({message}) {
 if(message.type==='system')return <p className="system-message">{message.text}</p>;
 return <div className={`message-row ${message.self?'own':''}`}>{!message.self&&<span className="avatar small purple">{message.initials||message.sender?.slice(0,2)||'У'}</span>}<div className="message-bubble">{!message.self&&<strong className="sender">{message.sender||'Участник'}</strong>}<p>{message.text}</p><div className="message-meta"><time>{message.time}</time>{message.self&&<CheckCheck size={14} aria-label="Отправлено"/>}</div></div></div>
}
