import React from 'react';
import {useState} from 'react';
import {Send, Smile} from 'lucide-react';
export default function InputField({value,onChange,onSend,disabled}){
 const [emoji,setEmoji]=useState(false);
 return <div className="composer-area"><form className="composer" onSubmit={e=>{e.preventDefault();onSend();}}><div className="emoji-wrap"><button type="button" className="icon-button" aria-label="Добавить эмодзи" aria-expanded={emoji} onClick={()=>setEmoji(!emoji)}><Smile size={22}/></button>{emoji&&<div className="emoji-picker">{['👋','😊','❤️','👍','🙌','✨','🎉','💡'].map(s=><button type="button" key={s} onClick={()=>{onChange(value+s);setEmoji(false)}}>{s}</button>)}</div>}</div><textarea aria-label="Сообщение" rows="1" placeholder="Написать сообщение…" value={value} maxLength={4000} onChange={e=>onChange(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.nativeEvent.isComposing){e.preventDefault();onSend()}}}/><button className="send-button" type="submit" aria-label="Отправить сообщение" disabled={disabled||!value.trim()}><Send size={19}/></button></form><div className="composer-hint"><span>Enter — отправить <span className="hint-divider">·</span> Shift + Enter — новая строка</span><span>{value.length>3500?`${value.length}/4000`:'Сделано для общения'}</span></div></div>
}
