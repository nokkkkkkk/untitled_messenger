export const chats = [
 {id: 'team', name: 'Команда проекта', initials: 'КП', color: 'green', description: 'Пространство для идей и нашего мессенджера', members: '3 участника', unread: 2, time: '12:42', preview: 'Михаил: Всё, сервер готов к подключению 🙌'},
 {id: 'design', name: 'Дизайн и интерфейс', initials: 'ДИ', color: 'purple', description: 'Обсуждаем детали интерфейса', members: '2 участника', time: '11:38', preview: 'Давай попробуем светлую тему'},
 {id: 'mikhail', name: 'Михаил Алексеев', initials: 'МА', color: 'blue', description: 'Личный диалог · демо', members: 'был сегодня в 11:05', time: '11:05', preview: 'Да, WebSocket уже работает'},
 {id: 'notes', name: 'Избранное', initials: '✧', color: 'sand', description: 'Ваши заметки, ссылки и хорошие идеи', members: 'Только вы', time: 'Вчера', preview: 'Идея: добавить переключение темы'},
];
export const initialMessages = {
 team: [
 {id:'t1', sender:'Михаил Алексеев', initials:'МА', text:'Привет! Здесь будем собирать всё по нашему мессенджеру 👋', time:'12:30'},
 {id:'t2', sender:'Анна', initials:'А', text:'Привет! Как продвигается интерфейс?', time:'12:32'},
 {id:'t3', self:true, text:'Уже собираю. Хочется сделать что-то простое и удобное, чтобы ничего не отвлекало от общения.', time:'12:35'},
 {id:'t4', sender:'Анна', initials:'А', text:'Мне нравится! И тёмную тему обязательно :)', time:'12:37'},
 {id:'t5', self:true, text:'Договорились. Переключатель уже на месте ✨', time:'12:39'},
 {id:'t6', sender:'Михаил Алексеев', initials:'МА', text:'Всё, сервер готов к подключению 🙌', time:'12:42'}
 ], design:[{id:'d1', sender:'Анна', initials:'А',text:'Давай попробуем светлую тему',time:'11:38'}],
 mikhail:[{id:'m1',sender:'Михаил Алексеев',initials:'МА',text:'Да, WebSocket уже работает',time:'11:05'}],
 notes:[{id:'n1',self:true,text:'Идея: добавить переключение темы',time:'Вчера'}]
};
export function readStored(key, fallback) {try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }}
export function store(key, value) {try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* Private browsing and storage limits must not break the chat. */ }}

export function makeId() { return globalThis.crypto?.randomUUID?.() || Array.from(globalThis.crypto.getRandomValues(new Uint8Array(16)), n => n.toString(16).padStart(2,'0')).join(''); }
